import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, Pressable, StatusBar, View } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, Color, FontSize, Padding } from "../GlobalStyles";

const TravelWow2 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.travelWow2}>
      <Image
        style={styles.travelWow2Child}
        contentFit="cover"
        source={require("../assets/group-215.png")}
      />
      <Text
        style={[styles.makeYourOwn, styles.yourLayout]}
      >{`Make your own private 
travel plan`}</Text>
      <Text
        style={[styles.formulateYourStrategy, styles.yourLayout]}
      >{`Formulate your strategy to receive 
wonderful gift packs`}</Text>
      <Pressable
        style={[styles.vectorWrapper, styles.vectorWrapperPosition]}
        onPress={() =>
          navigation.navigate("BottomTabsRoot", { screen: "TravelWow3" })
        }
      >
        <Image
          style={styles.vectorIcon}
          contentFit="cover"
          source={require("../assets/vector.png")}
        />
      </Pressable>
      <Image
        style={styles.travelWowDdOliveGreen1}
        contentFit="cover"
        source={require("../assets/travel-wow-dd-olive-green-1.png")}
      />
      <StatusBar style={styles.vectorWrapperPosition} barStyle="default" />
    </View>
  );
};

const styles = StyleSheet.create({
  yourLayout: {
    width: 328,
    textAlign: "center",
    position: "absolute",
  },
  vectorWrapperPosition: {
    flexDirection: "row",
    left: "50%",
    position: "absolute",
  },
  travelWow2Child: {
    height: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    maxWidth: "100%",
    maxHeight: "100%",
    opacity: 0.05,
    position: "absolute",
    overflow: "hidden",
    width: "100%",
  },
  makeYourOwn: {
    top: 370,
    left: 16,
    fontSize: 28,
    letterSpacing: -0.4,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    color: Color.colorBlack,
  },
  formulateYourStrategy: {
    top: 474,
    left: 10,
    fontSize: FontSize.size_lg,
    letterSpacing: -0.3,
    fontFamily: FontFamily.poppinsRegular,
    color: "#b4b4b4",
  },
  vectorIcon: {
    width: 35,
    height: 35,
  },
  vectorWrapper: {
    marginLeft: -37,
    top: 615,
    borderRadius: 90,
    backgroundColor: Color.colorGold,
    padding: Padding.p_xl,
  },
  travelWowDdOliveGreen1: {
    marginTop: -180,
    marginLeft: -95,
    top: "50%",
    width: 190,
    height: 100,
    left: "50%",
    position: "absolute",
  },
  travelWow2: {
    backgroundColor: Color.colorWhite,
    flex: 1,
    height: 800,
    overflow: "hidden",
    width: "100%",
  },
});

export default TravelWow2;
