import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, StatusBar, View } from "react-native";
import { Color } from "../GlobalStyles";

const TravelWow1 = () => {
  return (
    <View style={styles.travelWow1}>
      <Image
        style={[styles.travelWowDdOliveGreen1, styles.travelPosition]}
        contentFit="cover"
        source={require("../assets/travel-wow-dd-olive-green-1.png")}
      />
      <StatusBar style={styles.travelPosition} barStyle="default" />
    </View>
  );
};

const styles = StyleSheet.create({
  travelPosition: {
    left: "50%",
    position: "absolute",
  },
  travelWowDdOliveGreen1: {
    marginTop: -50,
    marginLeft: -95,
    top: "50%",
    width: 190,
    height: 100,
  },
  travelWow1: {
    backgroundColor: Color.colorGold,
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
  },
});

export default TravelWow1;
