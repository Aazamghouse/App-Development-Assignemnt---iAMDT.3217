import * as React from "react";
import { Text, StyleSheet, ScrollView, View, StatusBar } from "react-native";
import { Image } from "expo-image";
import { Color, FontFamily, FontSize, Border, Padding } from "../GlobalStyles";

const TravelWow3 = () => {
  return (
    <View style={styles.travelWow3}>
      <Text style={[styles.findYourNext, styles.searchTypo]}>
        Find your next trip
      </Text>
      <Text style={[styles.pearlOfThe, styles.popularTypo]}>
        Pearl of the Indian Ocean
      </Text>
      <Text style={[styles.popularLocations, styles.popularTypo]}>
        Popular locations
      </Text>
      <ScrollView
        style={styles.groupParent}
        horizontal={true}
        showsVerticalScrollIndicator={false}
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.frameScrollViewContent}
      >
        <View style={styles.groupLayout2}>
          <Image
            style={[styles.groupChild, styles.groupLayout1]}
            contentFit="cover"
            source={require("../assets/rectangle-595.png")}
          />
          <Text style={styles.sigiriya}>Sigiriya</Text>
          <Text style={styles.from699}>from $699</Text>
        </View>
        <View style={[styles.rectangleGroup, styles.groupLayout2]}>
          <Image
            style={[styles.groupChild, styles.groupLayout1]}
            contentFit="cover"
            source={require("../assets/rectangle-5951.png")}
          />
          <Text style={styles.sigiriya}>Dambulla</Text>
          <Text style={styles.from699}>from $549</Text>
        </View>
      </ScrollView>
      <Text style={[styles.popularHotels, styles.popularTypo]}>
        Popular Hotels
      </Text>
      <ScrollView
        style={styles.groupContainer}
        horizontal={true}
        showsVerticalScrollIndicator={false}
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.frameScrollView1Content}
      >
        <View style={styles.groupLayout}>
          <Image
            style={[styles.groupInner, styles.groupLayout]}
            contentFit="cover"
            source={require("../assets/rectangle-596.png")}
          />
          <Text style={[styles.radissonBlu, styles.gallePosition]}>
            Radisson Blu
          </Text>
          <Text style={[styles.galle, styles.gallePosition]}>Galle</Text>
        </View>
        <View style={[styles.groupView, styles.groupLayout]}>
          <Image
            style={[styles.groupInner, styles.groupLayout]}
            contentFit="cover"
            source={require("../assets/rectangle-5961.png")}
          />
          <Text style={[styles.radissonBlu, styles.gallePosition]}>
            Hilton Yala
          </Text>
          <Text style={[styles.galle, styles.gallePosition]}>
            Tissamaharama
          </Text>
        </View>
        <View style={[styles.groupView, styles.groupLayout]}>
          <Image
            style={[styles.groupInner, styles.groupLayout]}
            contentFit="cover"
            source={require("../assets/rectangle-5962.png")}
          />
          <Text style={[styles.radissonBlu, styles.gallePosition]}>
            Galadari
          </Text>
          <Text style={[styles.galle, styles.gallePosition]}>Colombo</Text>
        </View>
      </ScrollView>
      <Image
        style={styles.vectorIcon}
        contentFit="cover"
        source={require("../assets/vector7.png")}
      />
      <StatusBar barStyle="default" />
      <View style={[styles.frameView, styles.groupLayout1]}>
        <Image
          style={styles.vectorIcon2}
          contentFit="cover"
          source={require("../assets/vector8.png")}
        />
        <Text style={[styles.search, styles.searchTypo]}>Search..</Text>
      </View>
      <View style={styles.vectorWrapper}>
        <Image
          style={styles.vectorIcon2}
          contentFit="cover"
          source={require("../assets/vector7.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  frameScrollViewContent: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  frameScrollView1Content: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "flex-start",
  },
  searchTypo: {
    textAlign: "left",
    color: Color.colorGray_100,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    fontSize: FontSize.size_base,
  },
  popularTypo: {
    color: Color.colorBlack,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    textAlign: "left",
    position: "absolute",
  },
  groupLayout1: {
    borderRadius: Border.br_xl,
    position: "absolute",
  },
  groupLayout2: {
    height: 140,
    width: 230,
  },
  groupLayout: {
    height: 200,
    width: 140,
  },
  gallePosition: {
    left: 17,
    color: Color.colorWhite,
    fontFamily: FontFamily.andika,
    textAlign: "left",
    position: "absolute",
  },
  homeTypo: {
    marginTop: 5,
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.poppinsRegular,
    textAlign: "left",
  },
  findYourNext: {
    top: 80,
    left: 26,
    position: "absolute",
  },
  pearlOfThe: {
    top: 105,
    fontSize: 24,
    left: 26,
  },
  popularLocations: {
    top: 271,
    fontSize: FontSize.size_lg,
    left: 20,
  },
  groupChild: {
    left: 0,
    borderRadius: Border.br_xl,
    top: 0,
    height: 140,
    width: 230,
  },
  sigiriya: {
    top: 76,
    fontSize: FontSize.size_3xl,
    color: Color.colorWhite,
    fontFamily: FontFamily.andika,
    left: 20,
    textAlign: "left",
    position: "absolute",
  },
  from699: {
    top: 112,
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_xs,
    color: Color.colorWhite,
    left: 20,
    textAlign: "left",
    position: "absolute",
  },
  rectangleGroup: {
    marginLeft: 10,
  },
  groupParent: {
    top: 313,
    left: 20,
    position: "absolute",
    width: "100%",
  },
  popularHotels: {
    top: 503,
    fontSize: FontSize.size_lg,
    left: 20,
  },
  groupInner: {
    borderRadius: Border.br_xl,
    position: "absolute",
    left: 0,
    top: 0,
  },
  radissonBlu: {
    top: 117,
    fontSize: FontSize.size_lg,
  },
  galle: {
    top: 146,
    fontSize: FontSize.size_xs,
    left: 17,
  },
  groupView: {
    marginLeft: 10,
  },
  groupContainer: {
    top: 545,
    left: 20,
    position: "absolute",
    width: "100%",
  },
  vectorIcon: {
    height: "2.5%",
    width: "5.56%",
    top: "23.38%",
    right: "10%",
    bottom: "74.13%",
    left: "84.44%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  vectorIcon2: {
    width: 20,
    height: 20,
  },
  search: {
    marginLeft: 10,
  },
  frameView: {
    top: 173,
    borderStyle: "solid",
    borderColor: Color.colorGainsboro_200,
    borderWidth: 1,
    width: 248,
    paddingHorizontal: Padding.p_xl,
    paddingVertical: Padding.p_smi,
    alignItems: "center",
    flexDirection: "row",
    left: 20,
  },
  vectorWrapper: {
    top: 171,
    left: 290,
    borderRadius: 30,
    backgroundColor: Color.colorDarkslategray_200,
    padding: 15,
    flexDirection: "row",
    position: "absolute",
  },
  travelWow3: {
    flex: 1,
    height: 800,
    overflow: "hidden",
    width: "100%",
    backgroundColor: Color.colorWhite,
  },
});

export default TravelWow3;
