import * as React from "react";
import { Text, StyleSheet, View, StatusBar } from "react-native";
import { Image } from "expo-image";
import { FontFamily, FontSize, Color, Padding, Border } from "../GlobalStyles";

const TravelWow5 = () => {
  return (
    <View style={styles.travelWow5}>
      <Text style={styles.signIn}>Sign in</Text>
      <Image
        style={styles.arrowBackFill0Wght300Grad0Icon}
        contentFit="cover"
        source={require("../assets/arrow-back-fill0-wght300-grad0-opsz24-1.png")}
      />
      <View style={styles.vectorParent}>
        <Image
          style={styles.vectorIcon}
          contentFit="cover"
          source={require("../assets/vector9.png")}
        />
        <Text style={[styles.enterEMailAddress, styles.orContinueWithTypo]}>
          Enter e-mail address
        </Text>
      </View>
      <View style={[styles.travelWow5Child, styles.travelPosition]} />
      <Text style={[styles.orContinueWith, styles.orContinueWithTypo]}>
        Or continue with
      </Text>
      <View style={[styles.travelWow5Item, styles.travelPosition]} />
      <View style={[styles.rectangleParent, styles.groupLayout]}>
        <View style={[styles.groupChild, styles.groupInnerPosition]} />
        <View
          style={[styles.continueWithGoogleParent, styles.continuePosition]}
        >
          <Text style={[styles.continueWithGoogle, styles.continueTypo]}>
            Continue with Google
          </Text>
          <Image
            style={[styles.groupItem, styles.groupItemLayout]}
            contentFit="cover"
            source={require("../assets/group-6935.png")}
          />
        </View>
      </View>
      <View style={[styles.rectangleGroup, styles.groupLayout]}>
        <View style={[styles.groupInner, styles.groupInnerPosition]} />
        <View style={styles.xmlid834Parent}>
          <Image
            style={[styles.xmlid834Icon, styles.groupItemLayout]}
            contentFit="cover"
            source={require("../assets/xmlid-834.png")}
          />
          <Text style={[styles.continueWithFacebook, styles.continueTypo]}>
            Continue with Facebook
          </Text>
        </View>
      </View>
      <View style={[styles.rectangleContainer, styles.groupLayout]}>
        <View style={[styles.rectangleView, styles.groupInnerPosition]} />
        <View style={[styles.continueWrapper, styles.continuePosition]}>
          <Text style={[styles.continue, styles.continueTypo]}>Continue</Text>
        </View>
      </View>
      <StatusBar style={styles.groupInnerPosition} barStyle="default" />
    </View>
  );
};

const styles = StyleSheet.create({
  orContinueWithTypo: {
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_base,
    textAlign: "left",
  },
  travelPosition: {
    height: 1,
    backgroundColor: Color.colorGainsboro_100,
    top: 267,
    position: "absolute",
  },
  groupLayout: {
    height: 50,
    width: 320,
  },
  groupInnerPosition: {
    top: 0,
    position: "absolute",
  },
  continuePosition: {
    top: 13,
    height: 24,
    position: "absolute",
  },
  continueTypo: {
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    top: 0,
    fontSize: FontSize.size_base,
    textAlign: "left",
    position: "absolute",
  },
  groupItemLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    left: "0%",
    position: "absolute",
    overflow: "hidden",
  },
  homeTypo: {
    marginTop: 5,
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.poppinsRegular,
    textAlign: "left",
  },
  signIn: {
    top: 115,
    fontSize: 30,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    color: "#1f1f1f",
    textAlign: "left",
    left: 20,
    position: "absolute",
  },
  arrowBackFill0Wght300Grad0Icon: {
    top: 70,
    width: 24,
    height: 24,
    left: 20,
    position: "absolute",
    overflow: "hidden",
  },
  vectorIcon: {
    width: 19,
    height: 15,
  },
  enterEMailAddress: {
    color: "#adadad",
    width: 184,
    marginLeft: 10,
  },
  vectorParent: {
    top: 175,
    borderStyle: "solid",
    borderColor: Color.colorGainsboro_200,
    borderWidth: 1,
    paddingLeft: Padding.p_xl,
    paddingTop: Padding.p_smi,
    paddingRight: 49,
    paddingBottom: Padding.p_smi,
    alignItems: "center",
    flexDirection: "row",
    width: 320,
    borderRadius: Border.br_xl,
    left: 20,
    position: "absolute",
  },
  travelWow5Child: {
    width: 105,
    left: 0,
  },
  orContinueWith: {
    top: 255,
    left: 115,
    color: Color.colorBlack,
    position: "absolute",
  },
  travelWow5Item: {
    left: 256,
    width: 104,
  },
  groupChild: {
    backgroundColor: Color.colorDarkslategray_100,
    height: 50,
    width: 320,
    left: 0,
    borderRadius: Border.br_xl,
    top: 0,
  },
  continueWithGoogle: {
    left: 32,
    color: Color.colorWhite,
  },
  groupItem: {
    height: "91.67%",
    width: "10.68%",
    top: "4.17%",
    right: "89.32%",
    bottom: "4.17%",
  },
  continueWithGoogleParent: {
    left: 57,
    width: 206,
  },
  rectangleParent: {
    top: 309,
    left: 20,
    position: "absolute",
  },
  groupInner: {
    backgroundColor: "#3b5896",
    height: 50,
    width: 320,
    left: 0,
    borderRadius: Border.br_xl,
    top: 0,
  },
  xmlid834Icon: {
    height: "83.33%",
    width: "4.7%",
    top: "8.33%",
    right: "95.3%",
    bottom: "8.33%",
  },
  continueWithFacebook: {
    color: "#f5f5f5",
    left: 20,
  },
  xmlid834Parent: {
    height: "48%",
    width: "67.22%",
    top: "26%",
    right: "16.53%",
    bottom: "26%",
    left: "16.25%",
    position: "absolute",
  },
  rectangleGroup: {
    top: 380,
    left: 20,
    position: "absolute",
  },
  rectangleView: {
    backgroundColor: Color.colorGold,
    height: 50,
    width: 320,
    left: 0,
    borderRadius: Border.br_xl,
    top: 0,
  },
  continue: {
    color: Color.colorDarkslategray_100,
    left: 0,
  },
  continueWrapper: {
    left: 123,
    width: 74,
  },
  rectangleContainer: {
    top: 640,
    left: 20,
    position: "absolute",
  },
  travelWow5: {
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
    backgroundColor: Color.colorWhite,
  },
});

export default TravelWow5;
