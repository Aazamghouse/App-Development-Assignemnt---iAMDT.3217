import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, StatusBar, View } from "react-native";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const TravelWow4 = () => {
  return (
    <View style={styles.travelWow4}>
      <Image
        style={[
          styles.danieleFranchiS9ln3vb47gwUnIcon,
          styles.travelWow4ItemPosition,
        ]}
        contentFit="cover"
        source={require("../assets/danielefranchis9ln3vb47gwunsplash-1.png")}
      />
      <Text style={styles.sigiriyaRock}>Sigiriya Rock</Text>
      <Text style={styles.aUnescoWorld} numberOfLines={2}>
        A UNESCO World Heritage Site that stands as a testament to Sri Lanka's
        rich cultural and historical legacy.
      </Text>
      <Text style={styles.seeReviews}>See reviews</Text>
      <Image
        style={styles.travelWow4Child}
        contentFit="cover"
        source={require("../assets/group-6953.png")}
      />
      <StatusBar style={styles.travelWow4ItemPosition} barStyle="default" />
    </View>
  );
};

const styles = StyleSheet.create({
  travelWow4ItemPosition: {
    left: "50%",
    top: 0,
    marginLeft: -180,
    position: "absolute",
  },
  homeTypo: {
    marginTop: 5,
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.poppinsRegular,
    textAlign: "left",
  },
  danieleFranchiS9ln3vb47gwUnIcon: {
    width: 360,
    height: 800,
    top: 0,
    marginLeft: -180,
  },
  sigiriyaRock: {
    marginTop: 87,
    top: "50%",
    left: 20,
    fontSize: 42,
    fontFamily: FontFamily.andika,
    textAlign: "left",
    color: Color.colorWhite,
    position: "absolute",
  },
  aUnescoWorld: {
    marginLeft: -160,
    top: 555,
    fontSize: FontSize.size_base,
    lineHeight: 26,
    color: "rgba(255, 255, 255, 0.8)",
    width: 320,
    height: 78,
    fontFamily: FontFamily.poppinsRegular,
    textAlign: "left",
    left: "50%",
    position: "absolute",
    overflow: "hidden",
  },
  seeReviews: {
    top: 653,
    left: 258,
    lineHeight: 23,
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.poppinsRegular,
    textAlign: "left",
    color: Color.colorWhite,
    position: "absolute",
  },
  travelWow4Child: {
    height: "1.88%",
    width: "20.83%",
    top: "82.13%",
    right: "73.61%",
    bottom: "16%",
    left: "5.56%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  travelWow4: {
    flex: 1,
    width: "100%",
    overflow: "hidden",
    height: 800,
    backgroundColor: Color.colorWhite,
  },
});

export default TravelWow4;
