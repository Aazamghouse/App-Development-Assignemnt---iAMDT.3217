/* fonts */
export const FontFamily = {
  poppinsRegular: "Poppins-Regular",
  poppinsSemiBold: "Poppins-SemiBold",
  poppinsMedium: "Poppins-Medium",
  andika: "Andika",
};
/* font sizes */
export const FontSize = {
  size_lg: 18,
  size_sm: 14,
  size_base: 16,
  size_xs: 12,
  size_3xl: 22,
};
/* Colors */
export const Color = {
  colorWhite: "#fff",
  colorGray_100: "#818181",
  colorGray_200: "rgba(255, 255, 255, 0.25)",
  colorGold: "#f9e65c",
  colorBlack: "#000",
  colorSilver: "#bcbcbc",
  colorDarkslategray_100: "#333",
  colorDarkslategray_200: "#003642",
  colorGainsboro_100: "#e8e8e8",
  colorGainsboro_200: "#d9d9d9",
};
/* Paddings */
export const Padding = {
  p_base: 16,
  p_3xs: 10,
  p_xl: 20,
  p_2xl: 21,
  p_smi: 13,
};
/* border radiuses */
export const Border = {
  br_xl: 20,
};
