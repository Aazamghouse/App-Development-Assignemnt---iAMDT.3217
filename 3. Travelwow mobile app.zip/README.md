### To preview and run the project on your device:
1. Open project folder in <u>Visual Studio Code</u>
2. Run  `npm install`  in the terminal
3. Run  `npx expo start`  in the terminal
4. Run on For android device
    1. Press  `a`  to view on Android Virtual Device or follow the instructions [here](https://docs.expo.dev/workflow/run-on-device/) to run on a physical device.


### About the app:
`Travel Wow` is a hotel booking app which will help travellers browse and choose thier next destination or hotel.

- this app consists of a splash screen which will run for 2 seconds with the travel wow logo.
- once the splash screen has loaded, it will move you onto an onboarding, click the yellow `next` button to move on to the startup screen.
- over at the start up screen, you can horizontal scroll to see the `popular locations` and `popular Hotels`
- the bottom bar will navigate you throught the 02 other screens. `Guide` & `Account` 
